package ccup

object Test { //extends App {

  val g1 = Grid.random(10)
  println(g1)
  println("Up")
  println(g1.move(Up))
  println("Down")
  println(g1.move(Down))
  println("Right")
  println(g1.move(Right))
  println("Left")
  println(g1.move(Left))

}
