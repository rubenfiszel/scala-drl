package ccup

import util.Random

sealed trait Color
case object Blue extends Color
case object Red extends Color
case object Gray extends Color

object Piece {

  def toByte(piece: Piece):Int =
    toByte(piece.value, piece.color)

  def toByte(value: Int, color: Color):Int = {
    val c = color match {
      case Blue => 0
      case Red => 1
      case Gray => 2
    }
    c + value << 2
  }


  def row(v1: Int, v2:Int, v3:Int, v4:Int) = {
    v1 | v2 << 5 | v3 << 10 | v4 << 15
  }


}
case class Piece(value: Int, color: Color) {

  val MULT = 3
  def combine =
    copy(value = value*MULT)

  def log =
    Math.round(Math.log(value.toDouble)/Math.log(MULT)).toInt

/*  override def toString() = {
    val c = color match {
      case Blue => "B"
      case Red => "R"
      case Gray => "G"
    }
    c + log.toString
  }*/
}

object Grid {

  def apply(): GridIS =
    GridIS(IndexedSeq.fill(4,4)(None))

  def exponential(max:Int) =
    max-(Math.sqrt(Random.nextFloat*(max+1)*(max+1))).floor

  def randomPiece(nbP:Int, dominant:Color, max:Int) =
    if (Random.nextInt(16) < nbP) {
      val v = Math.pow(3, exponential(max)).toInt
      val c =
        if (Random.nextFloat < 0.3)
          dominant
        else
          Random.shuffle(Seq(Blue, Red, Gray)).head

      Some(Piece(v, c))
    }
    else {
      None
    }

  def random(turn:Int): GridIS = {
    val nbP = (Random.nextInt(17)+Random.nextInt(17))/2
    val c = Random.shuffle(Seq(Blue, Red, Gray)).head
    val max = (Math.log(turn/5)/Math.log(2)).toInt + 1
    val is =
      GridIS(IndexedSeq.fill(4,4)(randomPiece(nbP, c, max)))
    if (is.value > turn*4)
      random(turn)
    else
      is
  }

}

/*
grid coordinates expressed as yx:

11 12 13 13
21 22 23 24
31 32 33 34
41 42 43 44

 */

sealed trait Direction
case object Up extends Direction
case object Down extends Direction
case object Right extends Direction
case object Left extends Direction

trait Grid  {

  def parameters: Array[Float]
  def reward: Int
  def evalOpp: Double
  def eval: Double
  def value: Float
  def toInput: List[Float]
  def allSum: Array[Float]
  def place(x:Int, y: Int, piece: Piece): Option[Grid]
  def move(dir: Direction): (Grid, Float)
  def emptySpots: Seq[(Int, Int)]
  def get(x:Int, y:Int):Option[Piece]

}


case class GridBits(grid:IndexedSeq[Int]) extends Grid {

  def get(x:Int, y:Int):Option[Piece] = None
  def reward = 0
  def value = 0f
  def eval = 0
  def evalOpp = 0

  def parameters = Array(0f)
  def toInput = List()

  def allSum = Array()

  def place(piece: Piece, row: Int, x:Int):Int = {
    Piece.toByte(piece) << x*5 | (row & 0x1F << (x*5))
  }

  def place(x:Int, y: Int, piece: Piece): Option[Grid] =
    Some(copy(grid = grid.updated(place(piece, grid(y), x), y)))

  def emptySpots = {
    for {
      x <- 0 to 3
      y <- 0 to 3
      if ((grid(y) & (0x1F << (x*5))) != 0)
    } yield (x, y)
  }

  def move(dir: Direction) =
    (this, 0f) //TODO
         //  def setRow
  def getCol(x: Int) =
    ((grid(0) >> (5*x)) & 0x1F) | (((grid(1) >> (5*x)) & 0x1F) << 5) | (((grid(2) >> (5*x)) & 0x1F) << 10) | (((grid(2) >> (5*x)) & 0x1F) << 15)

  def invert(row: Int) =
    (row >> 15 & 0x1F) | ((row >> 10 & 0x1F) << 5) | ((row >> 5 & 0x1F) << 10) | ((row & 0x1F) << 15)

}

case class GridIS(grid: IndexedSeq[IndexedSeq[Option[Piece]]]) extends Grid {

  def get(x: Int, y:Int) =
    grid(y)(x)

  def row(y:Int) =
    grid(y)

  def col(x:Int) =
    (0 to 3).map(y => grid(y)(x)).toIndexedSeq

  def all =
    (0 to 15).map(i => grid(i/4)(i%4)).filter(_.isDefined).map(_.get)

  def place(x:Int, y:Int, piece: Piece):Option[GridIS] =
    if (get(x, y) == None)
      Some(copy(grid = grid.updated(y, grid(y).updated(x, Some(piece)))))
    else
      None

  def move(dir: Direction = Up) = {

    val ar = Array.fill[Option[Piece]](4, 4)(None)

    val ns =
      (dir == Up || dir == Down) //NORTHSOUTH
    val dr =
      (dir == Down || dir == Right) //DOWNRIGHT
    val range =
      if (dr)
        (3 to 0 by -1)
      else
        (0 to 3)

    var merge = 0f

    for (i <- 0 to 3) {

      var bef:Option[Piece] = None
      var inc =
        if (dr)
          4
        else
          -1

      for (j <- range) {

        val c =
          if (ns)
            grid(j)(i)
          else
            grid(i)(j)


        c match {
          case Some(x) if (bef.exists(_ == x)) =>

            val comb = Some(x.combine)

            merge += comb.get.value

            if (ns)
              ar(inc)(i) = comb
            else
              ar(i)(inc) = comb

            bef = None


          case Some(x) if (bef.exists(_.value == x.value)) =>
            if (ns)
              ar(inc)(i) = None
            else
              ar(i)(inc) = None

            if (dr)
              inc += 1
            else
              inc -= 1

            bef = None


          case sx@Some(x) =>
            if (dr)
              inc -= 1
            else
              inc += 1

            if (ns)
              ar(inc)(i) = sx
            else
              ar(i)(inc) = sx

            bef = sx

          case None => ()
        }
      }
    }
    (copy(grid = ar.map(_.toIndexedSeq).toIndexedSeq), merge)
  }


  def emptySpots =
    for {
      i <- 0 to 3
      j <- 0 to 3 if grid(j)(i) == None
    } yield (i, j)

  def value =
    grid.map(_.map(_.map(_.value).getOrElse(0)).sum).sum

  def edge =
      List(0, 3).map(row(_).map(_.map(_.value).getOrElse(0)).sum).sum +
  List(0, 3).map(col(_).map(_.map(_.value).getOrElse(0)).sum).sum


  def empty_squares = {
    grid.map(_.map(_.map(_.value.toFloat).getOrElse(0.5f)).sum).sum
  }

  def bestSum = {
    allSum.max
  }

  lazy val groupBycolor =
    (Piece(0, Red)::Piece(0, Blue)::Piece(0, Gray)::all.toList).groupBy(_.color).map(x => (x._1, x._2.map(_.value).sum))

  def allSum = {
    val a = groupBycolor.map(_._2)
    a.map(_.toFloat).toArray
//    a.map(x => if(x==a.max) x else 0f)
//    (l(0), l(1), l(2))
  }

  def countMerge(xs:List[Piece], c: Color):Int = {
    lazy val (a, b) = (xs.head, xs.tail.head)
    if (xs.length < 2) 0
    else if (a == b && a.color == c) 2 + countMerge(xs.tail.tail, c)
    else countMerge(xs.tail, c)
  }

  def countBadMerge(xs:List[Piece], c: Color):Int = {
    lazy val (a, b) = (xs.head, xs.tail.head)
    if (xs.length < 2) 0
    else if (a.value == b.value && a.color == c && a.color == b.color ) 2 + countBadMerge(xs.tail.tail, c)
    else countBadMerge(xs.tail, c)
  }


  def countDestroy(xs:List[Piece], c: Color):Int = {
    lazy val (a, b) = (xs.head, xs.tail.head)
    if (xs.length < 2) 0
    else if (a.value == b.value && (a.color == c || b.color == c) && a.color != b.color ) 2 + countDestroy(xs.tail.tail, c)
    else countDestroy(xs.tail, c)
  }

  def countBadDestroy(xs:List[Piece], c: Color):Int = {
    lazy val (a, b) = (xs.head, xs.tail.head)
    if (xs.length < 2) 0
    else if (a.value == b.value && (a.color != c && b.color != c) && a.color != b.color ) 2 + countBadDestroy(xs.tail.tail, c)
    else countBadDestroy(xs.tail, c)
  }

  val p = Array(0, 1, 8, 27, 64, 125, 217, 343)

  def countMonoton(xs:List[Option[Piece]], c: Color):Int = {
    lazy val (a, b) = (xs.head.getOrElse(Piece(0, c)), xs.tail.head)
    if (xs.length < 2) 0
    else if (b.isDefined && b.get.color == c && a.color == c && b.get.value > a.value) {
      p(b.get.log) - p(a.log) + countMonoton(xs.tail, c)
    }
    else countMonoton(xs.tail, c)
  }

  def merges(c: Color) = {
    val l = ((0 to 3).map(row).toList ::: (0 to 3).map(col).toList).map(_.foldLeft(List[Piece]())((acc, pos) => pos.map(_::acc).getOrElse(acc))).map(x => ((countMerge(x, c), countBadMerge(x, c)), (countDestroy(x, c), countBadDestroy(x, c)))).unzip

    val m = ((0 to 3).map(row).toList ::: (0 to 3).map(col).toList).map(_.toList).map(x => countMonoton(x, c).min(countMonoton(x.reverse, c)))


    val l1 = l._1.unzip
    val l2 = l._2.unzip
    (l1._1.sum, l1._2.sum, l2._1.sum, l2._2.sum, m.sum)
  }
  def empties = {
    emptySpots.size
  }

  def reward =
    empties + bestSum.toInt

  def heuristic = {


    val EVAL_EMPTY_WEIGHT        =   1.0;
    val EVAL_MERGE_WEIGHT        =   0.5;
    val EVAL_SUM_WEIGHT          =   2.0;
    val EVAL_DESTROYS_WEIGHT     =   0.75;
    val EVAL_MONOTONOCITY_WEIGHT =   0.001;
    val EVAL_BAD_MERGE_WEIGHT    =   0.5;
    val EVAL_BAD_SUM_WEIGHT      =   0.1;
    val EVAL_BAD_DESTROYS_WEIGHT =   0.2;


    val bestSum = allSum.max
    val bestColor = groupBycolor.filter(_._2 == bestSum).head._1
    val badSum = allSum.sum - bestSum
    val merge = merges(bestColor)

    EVAL_EMPTY_WEIGHT * empties +
    EVAL_MERGE_WEIGHT * merge._1 +
    EVAL_SUM_WEIGHT * bestSum +
    EVAL_BAD_DESTROYS_WEIGHT * merge._4 -
    EVAL_DESTROYS_WEIGHT * merge._3 -
    EVAL_BAD_SUM_WEIGHT * badSum -
    EVAL_BAD_MERGE_WEIGHT * merge._2
//    EVAL_MONOTONOCITY_WEIGHT * merge._5

  }

  def parameters = {
    val bestSum = allSum.max
    val bestColor = groupBycolor.filter(_._2 == bestSum).head._1
    val badSum = allSum.sum - bestSum
    val merge = merges(bestColor)

    Array(empties, bestSum, badSum, merge._1, merge._2, merge._3, merge._4, merge._5).map(_.toFloat)
  }

  def eval =
    heuristic

  def evalOpp =
    bestSum


  def cellToInputColor(opt: Option[Piece], color:Color):Float =
    opt.map(x => {
      if (color == x.color)
        x.value.toFloat
      else
        0f
    }).getOrElse(0f)

  def cellToInput(opt: Option[Piece]):List[Float] =
    opt.map(x => {
      val value = x.value.toFloat
      x.color match {
        case Blue => List(value, 0f, 0f)
        case Red => List(0f, value, 0f)
        case Gray => List(0f, 0f, value)
      }
    }).getOrElse(List(0f, 0f, 0f))

  lazy val toInput2:List[Float] = {
    val inp = for {
      i <- 0 to 3
      j <- 0 to 3
    } yield cellToInput(grid(j)(i))
    (inp.toList).flatten
  }

  def pow(i:Int, j:Int) = BigInt(i).pow(j).intValue

  lazy val toInput:List[Float] = {
    val clrs = for {
      c <- List(Blue, Red, Gray)
      i <- 0 to 3
      j <- 0 to 3
    } yield {
      if (grid(i)(j).exists(_.color == c))
        1f
      else
        0f
    }
    val inp = for {
      c <- List(Blue, Red, Gray)
      v <- 0 to Conf.maxTileValue
      i <- 0 to 3
      j <- 0 to 3
    } yield {
      if (grid(i)(j).equals(Some(Piece(pow(3, v), c))))
        1f
      else {
        0f
      }
    } //cellToInputColor(grid(j)(i), c)
    (clrs.toList:::inp.toList)
//    parameters.toList
  }


  lazy val toInputRed:List[Float] = {
    val inp = for {
      c <- List(Red)
      v <- 0 to 11
      i <- 0 to 3
      j <- 0 to 3
    } yield {
      if (grid(i)(j).equals(Some(Piece(pow(2, v), c))))
        1f
      else {
//        println(grid(i)(j) + " "  +Some(Piece(pow(2, v), c)))
        0f
      }
    } //cellToInputColor(grid(j)(i), c)
    (inp.toList)
//    parameters.toList
  }


  override def toString() = {
    val ESP = 3
    var str = ""
    str += "value: " + value + "\n"
    for (y <- 0 to 3) {
      str += "| "
      for (x <- 0 to 3) {
        val s = get(x, y).map(_.toString).getOrElse("_")
        val l = s.length/2.0
        str += (" "*ESP).drop(l.floor.toInt) + s + (" "*ESP).drop(l.ceil.toInt)
      }
      str += " |\n"
    }
    str
  }
}

object MoveMap {

  var map = Map[IndexedSeq[Option[Piece]], Array[Option[Piece]]]()

  def makeMove(is: IndexedSeq[Option[Piece]]) = {
    var bef:Option[Piece] = None
    var inc = -1
    val ar = Array.fill[Option[Piece]](4)(None)

    for (c <- is) {
      c match {
        case Some(x) if (bef.exists(_ == x)) =>
          val comb = Some(x.combine)
          ar(inc) = comb
          bef = None

        case Some(x) if (bef.exists(_.value == x.value)) =>
          ar(inc) = None
          inc -= 1
          bef = None


        case sx@Some(x) =>
          inc += 1
          ar(inc) = sx
          bef = sx

        case None => ()

      }

    }
    ar
  }

  def toPiece(c: Color, y: Int) =
    if (y == -1)
      None
    else
      Some(Piece(scala.math.pow(3, y).intValue, c))

  def loadMap(): Unit = {
    var i = 0
    for {
      c1 <- List(Blue, Red, Gray)
      c2 <- List(Blue, Red, Gray)
      c3 <- List(Blue, Red, Gray)
      c4 <- List(Blue, Red, Gray)
      y1 <- -1 to 8 if (y1 != -1 || c1 == Blue)
      y2 <- -1 to 8 if (y2 != -1 || c2 == Blue)
      y3 <- -1 to 8 if (y3 != -1 || c3 == Blue)
      y4 <- -1 to 8 if (y4 != -1 || c4 == Blue)
        }
    {
      i += 1
      if (i%1000 == 0)
        println(i)

      val l = IndexedSeq((c1, y1), (c2, y2), (c3, y3), (c4, y4))
      val lp = l.map(x => toPiece(x._1, x._2))
      val r = makeMove(lp)
      map += ((lp, r))
    }
  }
}
