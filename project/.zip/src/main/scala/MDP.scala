package ccup

import scalaz._

object MDP {

  trait Action

  type Value = Float
  type Reward = Float


  type A = Action
  type R = Reward
  type V = Value
  type SARS[S] = (S, A, R, S)

  type Odd = Float

  trait Statable[State] { //extends Monoid[State]

    type CAction <: Action

    def realizeTransition(state: State, action: CAction): (State, Reward)

    def applyTransition(state: State, action: Action): (State, Reward) =
      realizeTransition(state, cAction(action))

    def availableActions(state: State): Seq[Action]

    def zeroMove: Action

    def zero: State

    def allActions: IndexedSeq[Action]

    lazy val outputWidth =
      allActions.length

    lazy val featureSize =
      toInput(zero).length

    lazy val actionToIndex =
      allActions.zipWithIndex toMap

    def toString(state: State): String

    def toInput(state: State): IndexedSeq[Float]

    def cAction(a: Action) = a.asInstanceOf[CAction]

  }

  trait Valuable[S] extends Statable[S]{

    def value(state: S): Value

    def heuristic(state: S): Float

    def potentialStates(state: S, action: A): IndexedSeq[(S, Reward, Odd)]

//    def potStates(state: S, action: A): IndexedSeq[(S, Reward, Odd)] =
//      potentialStates(S, cAction(action))

  }

  implicit class StatableOps[S: Statable](state: S) {

    val F = implicitly[Statable[S]]

    override def toString =
      F.toString(state)

    def toInput =
      F.toInput(state)

    def applyTransition(action: A) =
      F.applyTransition(state, action)

    def availableActions: Seq[A] =
      F.availableActions(state)

    def randomAction: A =
      Rand.choose(availableActions)

    def availableActionsIndexs =
      availableActions.map(F.actionToIndex)

    def canContinue =
      !(F availableActions(state) isEmpty)

  }


  implicit class ValuableOps[V: Valuable](v: V) {

    val V = implicitly[Valuable[V]]

    def value =
      V.value(v)

    def heuristic =
      V.heuristic(v)

    def potentialStates(a: A): IndexedSeq[(V, Reward, Odd)] =
      V.potentialStates(v, a)

  }



  implicit object GameStatable extends Valuable[Game] {

    type CAction = Move

    val allActions = Game.moves

    val zero = Game(Grid(), 0, 0)

    val zeroMove = NoMove

    def realizeTransition(g: Game, m: CAction) = {
      val ng = g.move(m).get
      (ng, ng.value - g.value)
    }

    def potentialStates(g: Game, a: Action): IndexedSeq[(Game, Reward, Odd)] = {
      val (ng, rw) = realizeTransition(g, cAction(a))
      IndexedSeq((ng, rw, 1f))
    }

    def availableActions(g: Game) =
      g.availableMoveNext

    def value(g: Game) =
      g.value

    def heuristic(g: Game) =
      g.eval.toFloat

    def toInput(g: Game) =
      g.toInput

    def toString(g: Game) =
      g.toString

  }

  implicit object Game2048Statable extends Valuable[Game2048] {

    type CAction = Move

    val allActions = Game.ALL_TURNS

    val zero = Game2048(Grid(), 0)

    val zeroMove = NoMove

    def realizeTransition(g: Game2048, m: CAction) = {
      val ng = g.fullMove(m)
//      (ng, ng.value - g.value)
      ng
    }

    def potentialStates(g: Game2048, a: Action): IndexedSeq[(Game2048, Reward, Odd)] = {
      val (ng, rw) = g.move(cAction(a))
      val ngs = ng.grid.emptySpots.map(spot => ng.copy(grid = ng.grid.place(spot._1, spot._2, new Piece(1, Red)).get))
      ngs.map(x => (x, rw, 1f/ngs.length)).toIndexedSeq
    }

    def availableActions(g: Game2048) = {
        g.availableMoveNext
    }

    def value(g: Game2048) =
      g.value

    def heuristic(g: Game2048) =
      g.eval.toFloat

    def toInput(g: Game2048) =
      g.toInput.toIndexedSeq

    def toString(g: Game2048) =
      g.toString

  }




}
