package ccup


import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.api.ndarray.INDArray
import scala.util.Random
import org.deeplearning4j.util._
import org.deeplearning4j.nn.conf.graph._
import org.deeplearning4j.nn.graph.ComputationGraph
import org.deeplearning4j.nn.api.Model

import scala.collection.mutable.Queue

object TurnValue {


  def eval(g:Game, eval2: List[Game] => Array[Float]):Float = {
    if (g.canContinue) {
      val aM = g.availableMoveNext
      val gs = aM.map(m => g.move(m).get)
      eval2(gs).max
    } else
      g.grid.value
  }

}
