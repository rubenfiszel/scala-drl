/*package ccup

import breeze.linalg._
import breeze.linalg.any
import kr.ac.kaist.ir.deep.fn._
import kr.ac.kaist.ir.deep.train._
import kr.ac.kaist.ir.deep.network.Network

class GameType() extends ManipulationType[Game, ScalarMatrix] {

  val error = ManhattanErr
  val corrupt = NoCorruption

  val vt = new VectorType(corrupt, error)

  def corrupted(x:Game) = x

  def onewayTrip(net: Network, g:Game) = {
//    println("ONEWAYYY")
    net(g.toInput)
/*    val r = net(Game.newGame.toInput)
    println("R: " + r + net.W + g)
    System.exit(0)
    r
 */
  }

  def lossOf(net: Network)(pair: (Game, ScalarMatrix)) =
    vt.lossOf(net)((pair._1.toInput, pair._2))

  def roundTrip(net: Network, delta: Seq[ScalarMatrix]) = {
//    val eval = (g: Game) => onewayTrip(net, g)(0,0)
      (in: Game, real: ScalarMatrix) => {
  //    if (real(0,0) != 0f) {
        vt.roundTrip(net, delta)(in.toInput, real)
//        println("RT:" + (eval(in) - real(0,0)))
/*      }
      else
        vt.roundTrip(net, delta)(in.toInput, DenseMatrix(eval(in) + SelfPlay.error(in)(eval)))
      }
 */
    }
  }

  def stringOf(net: Network, in: (Game, ScalarMatrix)) =
    vt.stringOf(net, (in._1.toInput, in._2))


  //  override def corrupted(x: Game): ScalarMatrix = corrupt(x)

}
 */
