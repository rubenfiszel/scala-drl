package ccup


import org.deeplearning4j.nn.graph.ComputationGraph

import org.nd4j.linalg.factory.Nd4j
import org.deeplearning4j.optimize.listeners.ScoreIterationListener

import MDP._
import Backend._

object Conf {

  //Q-learning ? else Value Learning
  val dqn = false
  val seed = 12345678

  //6561
  val maxTileValue = 6
  val gameL = 1000


  val confNN:ConfNN = ConfDL4J(
    learningRate = 0.01f,
    l1 = None,
    l2 = Some(0.005f),

    nbHead = 5,
    commonHeight = 5,
    headHeight = 1,

    commonWidth = 128,
    headWidth = 128,
//    outputWidth = outputWidth,
    momentum = 0.95f,
    updater = RMSProp,
    activation = ReLu,
    seed = seed
  )

  def nbHead = confNN.nbHead


  //RL
  val lambda = 0.8f
  val batchSize = 50
  val maxEpsilon = 200*gameL/confNN.nbHead
  val disc = 1000f
  val gamma = 0.99f
  val targetNPeriod:Option[Int] = None
  val maskRand = 0.5f//0.5f
  val nbAvg = 10
  val rewardAtEnd = false

  //Q-Learning
  var zeroImpossible = false
  val expRep = true
  val minPoolFactor = 30
  val maxPoolFactor = 35

}

object SoloGame extends App {


    Nd4j.ENFORCE_NUMERICAL_STABILITY = true


  type Gam = Game

  val st = System.currentTimeMillis
  util.Random.setSeed(Conf.seed)

  // *** TEST ***//
//  val g = Grid().place( 3, 3, Piece(3, Red)).get
//  println(g.toInput)
//  System.exit(0)

  val evalP = TreeSearchP()
  val valP = TreeSearchP(1, false, false)
  val randomP = RandomPQ
  val mcst = MCST(100)
  val uct = UCT(1000)

  val pl = List(
//    MixedPolicy(1.0f, evalP, randomP),
//    MixedPolicy(0.95f, evalP, randomP),
//    MixedPolicy(0.99f, evalP, randomP)
//    MixedPolicy(0.0f, evalP, randomP),
    TreeSearchP(5, false, true)
//    MixedPolicy(1.0f, valP, randomP)
//    OppPolicy(valP, evalP),
//    OppPolicy(evalP, randomP)
//    uct
  )

  for (p <- pl) {
    ()
//    println(SelfPlay.testV[Gam](p, true))
  }

//  System.exit(0)

  val backend = implicitly[NeuralN[ComputationGraph]]
  val model = backend.build[Gam](Conf.confNN)


  val mp = DiscReward(model)
  val mpq = DiscRewardWithHead(model, 0)

/*  SelfPlay.testV[Gam](mp, true)
  println("::::::")
  SelfPlay.testV[Gam](mpq, true)

  System.exit(0)*/

//  model.outputS(Game.newGame)

  val epoch = 1


  for (i <- (1 to epoch)) {
    if (Conf.dqn)
      SelfPlay.trainModelRLDeepQ[Gam, ComputationGraph](model, 1000000)
    else
      SelfPlay.trainModelRLDeepV[Gam, ComputationGraph](model, 1000000)
    model.save("QDEEPi"+i+".json")
  }

  def timeSinceStart =
    (System.currentTimeMillis - st)/1000f

  val et =
  println("TIME: " + timeSinceStart)

}
