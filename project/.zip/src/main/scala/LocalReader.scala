package ccup

object LocalReader { //extends App {

//  MoveMap.loadMap()

  val I = 8628

  def read(str: String, web: Boolean = false) = {
    val splitted = str.split(',').toList
    val mvs =
      if (web)
        splitted.map(_.drop(2).dropRight(1))
      else
        splitted

    val cv = mvs.zipWithIndex.map(x => Log.readM(x._1, x._2 + 1))
    Log.read(cv)
  }

  def writeLog(log: Log, i: Int) = {
    var str = ""
    str += "score: " + log.hist.head._1.maxScore + "\n"
    str += log.hist.unzip._2.map(Log.writeM(_)).mkString(",") + "\n\n"
    scala.tools.nsc.io.File("games/"+i+".log").writeAll(str)
  }


  def readFile(i: Int) = {
    val file = scala.tools.nsc.io.File("games/"+i+".log")
    read(file.lines.drop(1).next)
//    printLog(log)
  }

  def printLog(log: Log) = {
    var i = 0
    log.hist.reverse.foreach( x => {
      println("Move: " + Log.writeM(x._2))
      println("Player: "+ ((i%2)+1))
//      val am = x._1.availableMove.map(Log.writeM(_)).mkString(", ")
//      println("AMove: " + am)
      println(x._1.grid)
//      println("BMove: " + Log.writeM(x._1.maxmax(4)))
//      println("Input: " + x._1.toInput)
      i += 1
    })


  }


  def createSet(file: scala.tools.nsc.io.File) = {
    val log = read(file.lines.drop(1).next)
    log
  }

  def createGameSet = {
    val files = scala.tools.nsc.io.Directory("games/").files.take(5000)
    files.map(createSet).foldLeft(List[List[Game]]())((acc, pos) => pos::acc)
  }


}
