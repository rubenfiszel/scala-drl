package ccup

import net.ruippeixotog.scalascraper.browser.Browser

object Crawler {//extends App {

  val FROM=8626
  val TO=19605

  val browser = new Browser()

  for (i <- FROM to TO) {
    val th = new Thread(new Runnable{
      def run(): Unit = {

        val doc = browser.get("http://www.codecup.nl/showgame.php?ga="+i.toString)
        if (!doc.title.contains("Oops")) {

          println(i)
          val mvs = doc.head.child(2).html().drop(12).dropRight(2)
          val log = LocalReader.read(mvs, true)
//          LocalReader.writeLog(log, i)

        }
      }
    }
    )
    th.start()
    th.join()
  }
}
