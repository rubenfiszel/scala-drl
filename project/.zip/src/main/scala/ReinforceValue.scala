package ccup


import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.api.ndarray.INDArray
import scala.util.Random
import org.deeplearning4j.nn.graph.ComputationGraph
import org.deeplearning4j.nn.api.Model
import org.deeplearning4j.datasets.fetchers._
import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.api.ndarray.INDArray
import org.deeplearning4j.nn.graph.ComputationGraph
import scala.collection.mutable.Queue
import org.nd4j.linalg.dataset._
import org.nd4j.linalg.dataset.api.iterator._
import org.nd4j.linalg.dataset.api.MultiDataSetPreProcessor
import scalax.chart.api._

import MDP._
import Backend._

class ValueLearning[S: Valuable, B: NeuralN](numEx:Int, model: B) extends RL[S, B](model){

  val mp = DiscReward(model)

  var target = model.cloneM

  def cloneTarget() = {
    println("CLONED")
    target = model.cloneM
  }


  val pols = (0 until Conf.nbHead).map(x => DiscRewardWithHead(model, x))

  def next() =
    next(Conf.batchSize)


  def tdErr(l:List[SARS[S]], k:Int = 0, b:Boolean):Array[Float] = {

    val last = l.last._4
    val ls  =
      l.map(_._1).toIndexedSeq :+ last

    val rewards = l.map(_._3)
    val preEv =
      if (!Conf.targetNPeriod.isDefined)
        model.output(ls).apply(k).map(_(0))
      else
        target.output(ls).apply(k).map(_(0))

    val evals = preEv.toArray

      if (!last.canContinue)
        evals(evals.length-1) = 0f

    val dt = (0 until ls.length-1).map(i => rewards(i)/Conf.disc + Conf.gamma*evals(i+1) - evals(i))

    var r = model.output(ls).apply(k).map(_(0)).init.toArray


    val br = r.toIndexedSeq

    if (b) {

      for (i <- (0 until r.length) ) {
        var ld = 1f
        var j = i
        while (j < r.length && ld > 0.005) {
          r(i) += ld*dt(j)
          ld *= Conf.lambda
          j += 1
        }
      }

//      println(evals.toList + " " + rewards + " " + dt + "\n \n")

    }

//    println("\n \n FINAL: "+ b + " " + (0 until br.length).map(i => (i, l(i)._1.value, (r(i)-br(i)).toString.take(8), br(i).toString.take(8))))

    r
  }


  def next(nb: Int) = {

    nbFetch += 1

    if (Conf.targetNPeriod.exists(p => nbFetch%p == 1))
      cloneTarget()

    //    val games = GameFetcher.genGames(nb)
    var fetched = List[List[SARS[S]]]()


    var fetchSize = 0
    while (fetchSize < nb) {
      fetched ::= sample[S](pols)
      fetchSize += fetched.head.length
    }


    if (nbFetch%10 == 0)
      test(SelfPlay.average[S](mp, 1)._1)

    val gameList =
      fetched.map(_.map(_._1)).flatten

    val scoreList = (0 until Conf.nbHead).map(k => fetched.map(x => {
      val b = (util.Random.nextFloat() > Conf.maskRand) || Conf.nbHead == 1
      tdErr(x, k, b)
    }).flatten.map(Array(_)).toArray)
    val (games, scores) = (gameList.toIndexedSeq, scoreList)
    output(games, scores)
  }


  def hasNext() =
    numEx > nbFetch

  def setPreProcessor(pp: MultiDataSetPreProcessor) =
    ()

  def reset() = {
  }


}
