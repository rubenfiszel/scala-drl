package ccup

import MDP._

class ExpReplayQ[S: Statable]() {

  var memory: List[SARS[S]] = List()
  var memSize = 0

  def reset() = {
    memSize = 0
    memory = List()
  }

  def add(lgame: List[SARS[S]]) = {
    memory :::= lgame
    memSize += lgame.length
  }

  def isEnough =
    memSize >= Conf.batchSize*Conf.minPoolFactor

  def isTooMuch =
    memSize > Conf.batchSize*Conf.maxPoolFactor

  def removeLast = {
    memSize -= 1
    memory = memory.dropRight(1)
  }

  def clean() = {
    while(isTooMuch)
      removeLast
  }

  def get(n: Int) = {

    var fetchSize = 0
    var fetched: List[SARS[S]] = List()

    while (fetchSize < n) {
      val ind = util.Random.nextInt(memory.length)
      fetched ::= memory(ind)
      fetchSize += 1
    }
    fetched
  }

}


/*
class ExpReplay[S: Statable]() {

  var memory: List[List[Game]] = List()
  var memSize = 0

  def reset() = {
    memSize = 0
    memory = List()
  }

  def add(lgame: List[Game]) = {
    memory ::= lgame
    memSize += lgame.length
  }

  def isEnough =
    memSize >= Conf.batchSize*Conf.minPoolFactor

  def isTooMuch =
    memSize > Conf.batchSize*Conf.maxPoolFactor

  def removeLast = {
    memSize -= memory.last.length
    memory = memory.dropRight(1)
  }

  def clean() = {
    while(isTooMuch)
      removeLast
  }

  def get(n: Int) = {
    var fetchSize = 0
    var fetched: List[List[Game]] = List()
    while (fetchSize < n) {
      val ind = util.Random.nextInt(memory.length)
      val fetch = RLValue.getAtRandomPoint(memory(ind), n)
      fetchSize += fetch.length
      fetched ::= fetch
    }
    fetched
  }

}
*/
