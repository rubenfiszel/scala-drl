package ccup


import java.nio.file.{Files, Paths}
import java.util.Random
import org.deeplearning4j.nn.conf.inputs.InputType
import org.deeplearning4j.nn.conf.preprocessor._
import org.deeplearning4j.optimize.listeners.ScoreIterationListener
import org.deeplearning4j.nn.graph.ComputationGraph
import org.deeplearning4j.nn.conf.ComputationGraphConfiguration
import org.apache.commons.io.FileUtils
import org.deeplearning4j.datasets.iterator.DataSetIterator
import org.deeplearning4j.datasets.iterator.impl.IrisDataSetIterator
import org.deeplearning4j.eval.Evaluation
import org.deeplearning4j.nn.api.{Layer, OptimizationAlgorithm}
import org.deeplearning4j.nn.conf.layers._
import org.deeplearning4j.nn.conf.{MultiLayerConfiguration, NeuralNetConfiguration, Updater}
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork
import org.deeplearning4j.nn.params.DefaultParamInitializer
import org.deeplearning4j.nn.weights.WeightInit
import org.nd4j.linalg.api.ndarray.INDArray
import org.nd4j.linalg.dataset.{DataSet, SplitTestAndTrain}
import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.lossfunctions.LossFunctions

//import org.deeplearning4j.ui._
import org.deeplearning4j.nn.conf.graph._
//import org.deeplearning4j.ui.weights._
import org.deeplearning4j.nn.api.Model;

import MDP._
import Backend._

object BuildNN {


  def buildOL(out: Int) = {
    new OutputLayer.Builder(LossFunctions.LossFunction.MSE)
      .nOut(out)
      .weightInit(WeightInit.XAVIER)
      .activation("identity")
      .build()
  }

  def buildDL(in:Int, out:Int, learningRate: Float):DenseLayer = {
      new DenseLayer.Builder()
        .nIn(in)
        .nOut(out)
        .weightInit(WeightInit.RELU)
        .learningRate(learningRate)
        .biasLearningRate(learningRate)
        .activation("relu")
        .build()
  }



  def buildCG[S: Statable](conf: ConfNN) = {

    //    val nccb = splitAndAdd(new NeuralNetConfiguration.Builder())
    val lr =
      if (conf.nbHead > 1)
        2*conf.learningRate
      else
        conf.learningRate

    val nccb = new NeuralNetConfiguration.Builder()
    val nconf = nccb
    //        .learningRate(learningRate)
      .learningRate(lr)
      .iterations(1) //makebetter

    conf.l1.foreach(x =>
      nconf
      .regularization(true)
      .l1(x)
    )

    conf.l2.foreach(x =>
      nconf
        .regularization(true)
        .l2(x)
    )

    conf.updater match {
      case Nesterovs => nconf.updater(Updater.NESTEROVS)
      case RMSProp => nconf.updater(Updater.RMSPROP)
    }

//      .dropOut(0.2)
//      .updater(Updater.ADAGRAD)

    val gb = nconf
      .momentum(conf.momentum)
      .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
      .seed(conf.seed)
      .graphBuilder()

    val fs = implicitly[Statable[S]].featureSize
    val os =
      if (Conf.dqn)
        implicitly[Statable[S]].allActions.length
      else
        1

    println(fs)
    gb
      .setInputTypes(InputType.feedForward(fs))

      .addInputs("input")
      .addLayer("L1", buildDL(fs, conf.commonWidth, lr/conf.nbHead), "input")

    for (i <- 2 to conf.commonHeight)
      gb.addLayer("L"+i, buildDL(conf.commonWidth, conf.commonWidth, lr/conf.nbHead), "L"+(i-1))

    if (conf.headHeight> 1) {
      for (i <- (2 to conf.nbHead))
        gb.addLayer("LH"+i+"-1", buildDL(conf.commonWidth, conf.commonWidth, lr), "L"+conf.commonHeight)


      for {
        i <- 1 to conf.nbHead
        j <- 3 to conf.headHeight
      }
      gb.addLayer("LH"+i+"-"+j, buildDL(conf.commonWidth, conf.headWidth, lr), "LH"+i+"-"+(j-1))


      for (i <- (1 to conf.nbHead))
        gb.addLayer("out"+i, buildOL(os), "LH"+i+"-"+conf.headHeight)
    } else {
      for (i <- (1 to conf.nbHead))
        gb.addLayer("out"+i, buildOL(os), "L"+conf.commonHeight)
    }

    val outs =
      (1 to conf.nbHead).map(i => "out"+i)

    gb
      .setOutputs(outs:_*)
      .build()


  }


}
