package ccup

import org.deeplearning4j.datasets.fetchers._
import org.deeplearning4j.datasets.iterator._
import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.api.ndarray.INDArray
import org.deeplearning4j.nn.graph.ComputationGraph

object TurnMem {

  val ar = Array.fill(Conf.gameL+1)(0f)

  def fit(ds:DataSetIterator) {
    while(ds.hasNext) {
      val data = ds.next()
      val ft = data.getFeatures().data().asFloat()
      val outp = data.getLabels().data().asFloat()
      //      println(ft.toList)
      //      println(outp.toList)
      for (i <- (0 until ft.length)) {
        //        println(ar(i.toInt) + " " + i.toInt + outp(i.toInt))
        ar(ft(i).toInt) += 0.01f*outp(i)
      }
      println(ar.zipWithIndex.mkString("\n"))
    }
  }

  def output(g:Game) = {
    if (g.canContinue)
      ar(g.turn)
    else
      0f
  }

}
