package ccup


import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.api.ndarray.INDArray
import scala.util.Random
import org.deeplearning4j.nn.graph.ComputationGraph
import org.deeplearning4j.nn.api.Model
import org.deeplearning4j.datasets.fetchers._
import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.api.ndarray.INDArray
import org.deeplearning4j.nn.graph.ComputationGraph
import scala.collection.mutable.Queue
import org.nd4j.linalg.dataset._
import org.nd4j.linalg.dataset.api.iterator._
import org.nd4j.linalg.dataset.api.MultiDataSetPreProcessor
import scalax.chart.api._

import MDP._
import Backend._

class QLearning[S: Statable, B: NeuralN](numEx:Int, model: B) extends RL[S, B](model) {

  val expRepQ = new ExpReplayQ[S]()

  val mpq = DiscRewardQ(model)

  var target = model.cloneM

  def cloneTarget() = {
    println("CLONED")
    target = model.cloneM
  }

  def getScore(s:S, head:Int = 0,  cg:B = model):Array[Float] = {
    val r = cg.outputS(s).apply(head)
//    println(r.toList)
    r
  }

  def ql(entry:SARS[S], b:Boolean)(head: Int):Array[Float] = {

    def getHeadScore(s:S) =
      getScore(s, head, model)

    val (s1, a, r, s2) = entry

    val ow = implicitly[Statable[S]].outputWidth

    var ar = Array.fill(ow)(0f)
    if (Conf.zeroImpossible) {
      val qs = DiscRewardQ.filterPossible(s1, getHeadScore(s1))
      qs.foreach(x =>
        ar(x._2) = x._1
      )
    }
    else
      ar = getHeadScore(s1)

    if (b) {

      if (!s1.canContinue) {
          ar = Array.fill(ow)(0f)
      }

      else  {
        val nqs:Float =
          if (s2.canContinue) {
            if (Conf.targetNPeriod.isDefined) {
              val maxA = DiscRewardQ.filterPossible(s2, getHeadScore(s2)).maxBy(_._1)._2
              DiscRewardQ.filterPossible(s2, getScore(s2, head, target)).find(_._2 == maxA).get._1
            }
            else {
              DiscRewardQ.filterPossible(s2, getHeadScore(s2)).maxBy(_._1)._1
            }
          }
          else {
            0f
            //RLValue.lastValue(g2)
          }

        val ind = s1.F.actionToIndex(a)
        ar(ind) = (r/Conf.disc + Conf.gamma*nqs)
        //      println(entry)
        //        println(ar(ind) + " !!!!! " + g1.turn)
        //        println("BEF"+  GameFetcher.rawOutput(model, g1)(head).data().asFloat().toArray.toList.head)
      }
    }

    if (s2.canContinue && false) {
      val hs = getHeadScore(s1)
//      println(r + " " + RLValue.reward(g1, g2))
      println(ar.toList)
      println(hs.toList)
//      println(b + " " + g1.turn + " " + g2.turn + " " + g2.value + " " + (0 until ar.length).map(i => ar(i) - hs(i)))
      }
    ar
  }


  val pols = (0 until Conf.nbHead).map(x => DiscRewardQWithHead(model, x))

  def next(nb: Int) = {

    nbFetch += 1

    if (Conf.targetNPeriod.exists(p => nbFetch%p ==1))
      cloneTarget()

    //    val games = GameFetcher.genGames(nb)
    var fetched = List[SARS[S]]()

    if (Conf.expRep) {
      expRepQ.add(sample[S](pols))
      fetched = expRepQ.get(nb)
      expRepQ.clean()
    }
    else {
      var fetchSize = 0
      while (fetchSize < nb) {
        fetched :::= sample[S](pols)
        fetchSize += fetched.length
      }
    }


    if (nbFetch%5 == 0)
      test(SelfPlay.testQ[S](mpq, false))


    val unzip = (0 until Conf.nbHead).map(k => fetched.map(x => {
      val b = (util.Random.nextFloat > Conf.maskRand) || Conf.nbHead == 1
      val r = ql(x, b)(k)
      r
    }).toArray)
    val games = fetched.map(_._1).toIndexedSeq
    output(games, unzip)
  }


  def hasNext() =
    numEx > nbFetch

  def setPreProcessor(pp: MultiDataSetPreProcessor) =
    ()

  def reset() = {
    expRepQ.reset()
  }


  def next() =
    next(Conf.batchSize)



}
