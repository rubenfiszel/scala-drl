/*package ccup


import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.api.ndarray.INDArray
import scala.util.Random
import org.deeplearning4j.util._
import org.deeplearning4j.nn.conf.graph._
import org.deeplearning4j.nn.graph.ComputationGraph
import org.deeplearning4j.nn.api.Model

import scala.collection.mutable.Queue

object Value {
  def td(game: Game)(eval: Game => Array[Float]): (INDArray, INDArray) = {
    val (games, scores) = error(game)(eval)
    val indGames = GameFetcher.genInput(games.toIndexedSeq).reshape(games.length, GameFetcher.featureSize)
    val indScores = scores.toArray.foldLeft(Array[Float]())( (acc, pos) => acc ++ pos)
    (
      indGames,
      Nd4j.create(indScores).reshape(games.length, 5)
    )
  }

  var tdnb = 0

  def turn(g:Game) = (g.turn%5)

  def error(game: Game)(eval: Game => Array[Float]): (List[Game], List[Array[Float]]) = {

    var games: List[Game] = List(game)
    var scores = List[Array[Float]]()

    def customEval(g: Game):Float =
      eval(g)(turn(g)) + g.grid.value - games.head.grid.value

    def editLabel(game:Game, v:Float) = {
      val ar = eval(game)
      ar(turn(game)) += v
      ar
    }

    def getHeuriGame(g:Game):Game = {
      val aM = g.availableMoveNext
      aM.map(m => g.move(m).get).maxBy(_.grid.eval)
    }

    def getMaxGame(g:Game) = {
      val aM = g.availableMoveNext
      aM.map(m => g.move(m).get).maxBy(customEval)
    }

    def getRandomNextGame(g:Game) = {
      val aM = g.availableMoveNext
      aM.map(m => g.move(m).get).toList(Random.nextInt(aM.length))
    }


    val N = 120

    var b = true
    while (games.length <= N && b) {
      val g = games.head
      if (!g.canContinue) {
        //        println(g.grid.value)
        b = false
        games ::= Game.newGame //to delete anyway
        scores ::= Array.fill(5)(0f)//editLabel(g, 0)
      }
      else {
        val rd = Random.nextFloat
        val ng =
          if (rd < -1f)
            g.applyRandomMove
          else if (rd < -1f)
            getHeuriGame(g)
          else
            getMaxGame(g)


        val diff =
          eval(ng)(turn(ng)) - eval(g)(turn(g)) + (ng.grid.value- g.grid.value)/10f
        //        println(diff)
        scores ::= editLabel(g, diff)
        games ::= ng
      }
    }
    //    println(games.tail.map(_.turn), scores.map(_.toList).flatten)
    (games.tail, scores)
  }
}


/*
//With Eligibility trace (hard
object Value3 {
  def td(game: Game)(eval: Game => Array[Float]): (INDArray, INDArray) = {
    val agg = (1 to 128).map(i => error(game)(eval)).foldLeft((Array[Game](), Array[Float]()))((acc, pos) =>
      (acc._1 ++ pos._1, acc._2 ++ pos._2))
    (GameFetcher.genInput(agg._1).reshape(agg._1.length, GameFetcher.featureSize), Nd4j.create(agg._2).reshape(agg._1.length, 1))
  }

  var tdnb = 0

  def turn(g:Game) = (g.turn%5)

  def error(gameInit: Game)(eval: Game => Array[Float]): (Array[Game], Array[Float]) = {

    var N = 2
    var searchResults = List[(Game, Float)]()

    def customEval(g: Game):Float =
      eval(g)(turn(g)) + g.grid.value - game.grid.value

    def staticEval(g:Game):Float =
      g.value

    var game = gameInit

    var i = 0
    while (i < N) {
      //      println(sn.node)
      if (!game.canContinue) {
        searchResults ::= ((game, game.value))//(game.grid.value-GameFetcher.mO)/GameFetcher.sO))
        i = N
    } else {
      val sp = SelfPlay.selfPlay2(game, 1)(customEval)(customEval)
      game = sp._1
      searchResults ::= ((sp._3, eval(sp._3)(turn(game))))
      i += 1
    }
  }

  searchResults = searchResults.reverse


  if (searchResults.length > 1) {
    val preinput = searchResults.map(_._1)
    val lg = preinput.length
    val input = preinput.init.toArray
    val dr =  (0 until lg-1).map(t => preinput(t+1).grid.value - preinput(t).grid.value)
    val output = searchResults.map(_._2).toArray
    val dts = (0 until lg-1).map(t => output(t+1) - output(t))
    /*
     println(preinput)
     println(dr)
     println(input.toList)
     println(output.toList)
     println(dts)
     */
    var disV = List[Float]()

    for ( i <- (0 until lg-1)) {
      var sum = 0f
      var delta = 1f
      for ( j <- (i until lg-1)) {
        sum += (dr(j)/1000 + dts(j)) * delta
        //          if (i == 0 && b)
        //            println("delta:" + delta + " error: " + (dr(j)/GameFetcher.sO) +" " +  dts(j))
        delta *= 0.8f
      }

      disV ::= sum
      //        if (err % 1 == 0 && b)
      //          println("error " + err + ": " + sum + " " + output(i))
    }

    disV = disV.reverse

    val q = Queue[Float]()
    q ++= disV
    //      println("td: " + tdnb)
    tdnb += 1
    //    println("Errors: " + q.mkString(" "))
    //      println("Output: " + output.mkString(" "))
//    val outn =  input.map(x => editLabel(, q.dequeue, turn(x))).toArray
    val in =  Array(searchResults.head._1)
    val outn =  Array(searchResults.head._2)
    (in, outn)
  }
  else {

    val in =  Array(searchResults.head._1)
    val outn =  Array(searchResults.head._2)
    (in, outn)
  }
}

}
*/
 */
