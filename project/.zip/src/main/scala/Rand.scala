package ccup

import util.Random

object Rand {

  def choose[A](s: Seq[A]):A = s(Random.nextInt(s.length))

}
