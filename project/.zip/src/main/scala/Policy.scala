package ccup

import org.deeplearning4j.nn.graph.ComputationGraph
import util.Random

import MDP._
import Backend._



trait Policy[G[_] <: Statable[_]]{

//  def foo[S: G](s: S): String

//  def bar[S: G](s: S): S
  def nextAction[S: G](s: S): A

//  def applyNext[S: G](s: S): (S, R) =
//   s.applyTransition(nextAction[S](s))
}
/*
object D extends Policy[Valuable] {
  def bar[S: Valuable](s: S) =
    s.F.zero
}

object E {
  D.bar[Game](Game.newGame)
}*/

trait PolicyQ extends Policy[Statable]{

  def nextAction[S: Statable](s: S): A

  def applyNext[S: Statable](s: S): (S, R) =
    s.applyTransition(nextAction(s))

}

trait PolicyV extends Policy[Valuable]{

  def nextAction[S: Valuable](s: S): A

  def applyNext[S: Valuable](s: S): (S, R) =
    s.applyTransition(nextAction(s))

}




object RandomPQ extends PolicyQ {

  def nextAction[S: Statable](s: S) =
    s.randomAction

}

case class TreeSearchP(depth: Int=1, expectimax: Boolean = false, heuristic: Boolean = true) extends PolicyV {

  def nextAction[S: Valuable](s: S) = {

    def eval(s: S): Value =
      if (heuristic)
        s.heuristic
      else
        s.value

    if (expectimax)
      TreeSearch.expectimax(s, depth, eval)._3
    else
      TreeSearch.maxmax(s, depth, eval)._3
  }

}


case class UCT(branches: Int = 100) extends PolicyV {

  def nextAction[S: Valuable](s: S) = {
    val mct = new MCTree(s, s.F.zeroMove)
    for (i <- 1 to branches)
      mct.iter()
    mct.bestMove
  }

}

case class MCST(branches: Int = 100) extends PolicyQ {

  def mtc[S: Statable](s: S, a: A) = {
      var r = 0f
      for (i <- (1 to branches)) {
        var (cs, rw) = s.applyTransition(a)
        r += rw
        while (cs.canContinue) {
          val na = RandomPQ.nextAction(cs)
          var (ns, rw) = cs.applyTransition(na)
          cs = ns
          r += rw
        }
//      println(r)
      }
    r
  }

  def nextAction[S: Statable](s: S) = {
    val r =  s.availableActions.map(a => (a, mtc(s, a)))
    println(r)
    r.maxBy(_._2)._1
}
  //  s.availableActions.maxBy(a => mtc(s, a))

}

/*case class DiscReward[B: NeuralN](model: B) extends PolicyV {

  def avg(l:Array[Array[Float]]) = {
    val nb = l.length
    (0 until l.head.length).map(x => (0 until Conf.nbHead).map(y => l(y)(x)).sum/nb.toFloat)
  }

  def nextAction[S: Valuable](s: S) = {
      val aA = s.availableActions
      val trans = aA.map(a => s.applyTransition(a))
      val cs = trans.map(_._1)
      val o = model.output(cs.toIndexedSeq).map(_.map(_(0)).toArray)
      val ev = avg(o).toIndexedSeq
      val values = trans.zip(ev).map(x => x._1._2 + x._2)
      val r = values.zip(aA).maxBy(_._1)._2
//      println(g.turn + " " + GameFetcher.rawOutput(model, g)(k).data.asFloat()(0))
      r
  }

}
 */

case class DiscReward[B: NeuralN](model: B) extends PolicyV {


  def potentials[S: Valuable](l: Seq[((A, (S, Reward, Odd)), Array[Float])]) = {
    def potential(e: ((A, (S, Reward, Odd)), Array[Float])) = {
//      println(e._2.toList)
      e._1._2._3*(e._2.sum/e._2.length + e._1._2._2/Conf.disc)
    }
    l.map(potential).sum
  }

  def nextAction[S: Valuable](s: S) = {
      val aA = s.availableActions
      val ps = aA.map(a => s.potentialStates(a).map(x => (a, x))).flatten
      val states = ps.map(_._2._1)
      val evals = model.output(states.toIndexedSeq).map(_.map(_(0)).toArray)
      val shifted = (0 until evals(0).length).map(y => (0 until evals.length).map(z => evals(z)(y)).toArray).toArray
      ps.zip(shifted).groupBy(_._1._1).mapValues(potentials[S]).maxBy(_._2)._1
  }

}


case class DiscRewardWithHead[B: NeuralN](model: B, k:Int) extends PolicyV {


  def potentials[S: Valuable](l: Seq[((A, (S, Reward, Odd)), Float)]) = {
    def potential(e: ((A, (S, Reward, Odd)), Float)) = {
      e._1._2._3*(e._2 + e._1._2._2/Conf.disc)
    }
//    println("HEAD "+l)
    l.map(potential).sum
  }

  var nb = 0

  def nextAction[S: Valuable](s: S) = {

    nb += 1
    val tresh = (nb.toFloat/Conf.maxEpsilon).min(0.99f)
    val rand =  util.Random.nextFloat() > tresh
    if (rand) {
//      println("BM:" + nb + " " + tresh )
      s.randomAction
    }
    else {
      val aA = s.availableActions
      val ps = aA.map(a => s.potentialStates(a).map(x => (a, x))).flatten
      val states = ps.map(_._2._1)
//      println(states+ " " + states.map(_.toInput))
      val evals = model.output(states.toIndexedSeq).apply(k).map(_(0)).toArray
      val r = ps.zip(evals).groupBy(_._1._1).mapValues(potentials[S]).maxBy(_._2)
//      println(r)
      r._1
    }
  }

}

/*
case class DiscRewardWithHead[B: NeuralN](model: B,  k:Int) extends PolicyQ {

  var nb = 0

  def nextAction[S: Statable](s: S) = {
    nb += 1

    val tresh = (nb.toFloat/Conf.maxEpsilon).min(0.99f)
    val rand =  util.Random.nextFloat() > tresh
//    println("BM:" + nb + " " + tresh )
    if (rand)
      s.randomAction
    else {
      val aA = s.availableActions
      val trans = aA.map(a => s.applyTransition(a))
      val cs = trans.map(_._1)
      val ev = model.output(cs.toIndexedSeq).apply(k).map(_(0))
      val values = trans.zip(ev).map(x => x._1._2 + x._2)
      val r = values.zip(aA).maxBy(_._1)._2
//      println(g.turn + " " + GameFetcher.rawOutput(model, g)(k).data.asFloat()(0))
      r
    }
  }

}
 */

object DiscRewardQ {

  def findMaxInd(l:IndexedSeq[(Float, Int)]) =
    l.maxBy(_._1)


  def filterPossible[S: Statable](s: S, mvs: IndexedSeq[Float]) = {
    val indexs = s.availableActions.map(x => s.F.actionToIndex(x))
    mvs.zipWithIndex.filter(x => indexs.contains(x._2))
  }

}


case class DiscRewardQWithHead[B: NeuralN](model: B, k:Int) extends PolicyQ {

  def max[S: Statable](l:Array[Float], s:S) = {
    val (r, n) = DiscRewardQ.findMaxInd(DiscRewardQ.filterPossible(s, l.toIndexedSeq))
//    println(r  + " " + s.value + " " + n)// + " " + DiscRewardQ.filterPossible(g, l.toIndexedSeq).mkString(", "))
    n
  }

  var nb = 0

  def nextAction[S: Statable](s: S) = {
    nb += 1

    val tresh = (nb.toFloat/Conf.maxEpsilon).min(0.99f)
    val rand =  util.Random.nextFloat() > tresh
//    println("BM:" + nb + " " + tresh )
    if (rand)
      s.randomAction
    else {
      val o = model.outputS(s).apply(k)
      s.F.allActions(
        max(o,s)
      )
    }
  }
}

case class DiscRewardQ[B: NeuralN](model: B) extends PolicyQ {

  def findMaxInd(l:IndexedSeq[(Float, Int)]) =
    l.maxBy(_._1)

  def max[S: Statable](l:IndexedSeq[Array[Float]], s: S) = {
    val maxWithInd = (0 until Conf.nbHead).map(y => DiscRewardQ.findMaxInd(
      DiscRewardQ.filterPossible(s, (0 until l.head.length).map(x => l(y)(x)))
    )).groupBy(_._2).map(x => (x._1, x._2.map(_._1)))
    var maxInd, nb = -1
    var maxSum = Float.MinValue
//    println("MAXXX:" + maxWithInd)
    maxWithInd.foreach(x =>
      if (x._2.length > nb || (x._2.length == nb && x._2.sum > maxSum)) {
        maxInd = x._1
        maxSum = x._2.sum
        nb = x._2.length
      }
    )
    maxInd
  }

  def nextAction[S: Statable](s: S) = {
    s.F.allActions(
      max(
        model.outputS(s),
        s)
    )
  }

}

case class MixedPolicy(odd: Float, p1:PolicyQ, p2:PolicyQ) extends PolicyQ {

  def nextAction[S: Statable](s: S) = {
    if (Random.nextFloat < odd)
      p1.nextAction(s)
    else
      p2.nextAction(s)
  }
}

case class OppPolicy(p1:PolicyQ, p2:PolicyQ) extends PolicyQ {

  var i = -1

  def nextAction[S: Statable](s: S) = {
    i += 1
    if (i%2 == 0)
      p1.nextAction(s)
    else
      p2.nextAction(s)
  }


}
