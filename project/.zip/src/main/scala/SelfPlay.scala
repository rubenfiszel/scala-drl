package ccup

import java.nio.file._
import java.util.Random
import org.deeplearning4j.nn.conf.inputs.InputType
import org.deeplearning4j.nn.conf.preprocessor._
import org.deeplearning4j.optimize.listeners.ScoreIterationListener
import org.deeplearning4j.nn.graph.ComputationGraph
import org.deeplearning4j.nn.conf.ComputationGraphConfiguration
import org.apache.commons.io.FileUtils
import org.deeplearning4j.datasets.iterator.DataSetIterator
import org.deeplearning4j.datasets.iterator.impl.IrisDataSetIterator
import org.deeplearning4j.eval.Evaluation
import org.deeplearning4j.nn.api.{Layer, OptimizationAlgorithm}
import org.deeplearning4j.nn.conf.layers._
import org.deeplearning4j.nn.conf.{MultiLayerConfiguration, NeuralNetConfiguration, Updater}
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork
import org.deeplearning4j.nn.params.DefaultParamInitializer
import org.deeplearning4j.nn.weights.WeightInit
import org.nd4j.linalg.api.ndarray.INDArray
import org.nd4j.linalg.dataset.{DataSet, SplitTestAndTrain}
import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.lossfunctions.LossFunctions
import org.slf4j.LoggerFactory
//import org.deeplearning4j.ui._
import org.deeplearning4j.util._
import org.deeplearning4j.nn.conf.graph._
//import org.deeplearning4j.ui.weights._
import org.deeplearning4j.nn.api.Model;
import java.io._

import scala.collection.mutable.Queue

import MDP._
import Backend._

object SelfPlay {

  lazy val log = LoggerFactory.getLogger(getClass())


  def trainModelRLDeepQ[S: Statable, B: NeuralN](model: B, numEx: Int) = {

    val iter =
        new QLearning[S, B](numEx, model)

    model.fit(iter)
    model
  }

  def trainModelRLDeepV[S: Valuable, B: NeuralN](model: B, numEx: Int) = {

    val iter =
        new ValueLearning[S, B](numEx, model)

    model.fit(iter)
//    println("DONE" + iter.nbFetch)
    model

  }



  def testQ[S: Statable](p:PolicyQ, track: Boolean=false) = {

    val F = implicitly[Statable[S]]
    var s = F.zero
    var r = 0f
    var i = 0
    while (s.canContinue) {
      if (track) {
        log.info(p.getClass.toString + " turn: " + i + " score: " + r)
        println(s)
      }
      val a = p.nextAction(s)
//      println(a)
      val (ns, rw) = s.applyTransition(a)
      s = ns
      r += rw
      i += 1
    }

    r
  }


  def testV[S: Valuable](p:PolicyV, track: Boolean=false) = {

    val F = implicitly[Statable[S]]
    var s = F.zero
    var r = 0f
    var i = 0
    while (s.canContinue) {
      if (track) {
        log.info(p.getClass.toString + " turn: " + i + " score: " + r)
        println(s)
      }
      val a = p.nextAction(s)
//      println(a)
      val (ns, rw) = s.applyTransition(a)
      s = ns
      r += rw
      i += 1
    }
    println("Score: " + r + " Turn:" +s.value)
    r
  }


  def average[S: Valuable](p: PolicyV, nb: Int = 100) = {
    val values = (1 to nb).map(x => testV[S](p))
    (values.sum/values.length.toFloat, values)
  }

}
