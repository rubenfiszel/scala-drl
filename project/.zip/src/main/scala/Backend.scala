package ccup

import org.deeplearning4j.util._
import org.deeplearning4j.nn.graph.ComputationGraph
import org.deeplearning4j.optimize.listeners.ScoreIterationListener
import org.nd4j.linalg.api.ndarray.INDArray
import java.io._
import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.dataset._

import MDP._

object Backend {

  type PreBatch[S] = (IndexedSeq[S], IndexedSeq[IndexedSeq[Array[Float]]])

  sealed trait Updater
  object RMSProp extends Updater
  object Nesterovs extends Updater

  sealed trait Activation
  object ReLu extends Activation

  trait ConfNN {
    def learningRate: Float
    def l1: Option[Float]
    def l2: Option[Float]
    def nbHead: Int
//    def divideRate: Floa
    def commonHeight: Int
    def headHeight: Int
    def commonWidth: Int
    def headWidth: Int
  //  def outputWidth: Int
    def momentum: Float
    def updater:Updater
    def activation: Activation
    def seed: Int
  }

  case class ConfDL4J(
    learningRate: Float = 0.005f,
    l1: Option[Float] = None,
    l2: Option[Float] = Some(0.005f),
    nbHead:Int = 10,
    commonHeight:Int = 3,
    headHeight:Int = 1,
    commonWidth:Int = 64,
    headWidth:Int = 128,
//    outputWidth: Int = Conf.outputWidth,
    momentum: Float = 0.9f,
    updater: Updater = Nesterovs,
    activation: Activation = ReLu,
    seed: Int = Conf.seed
  ) extends ConfNN

  trait NeuralN[NN] {

    type Batch

    def build[S: Statable](conf: ConfNN): NN
    def load(filename: String): NN
    def save(nn: NN, filename: String): Boolean
    def cloneM(nn: NN): NN
    def buildBatch[S: Statable](seqs: IndexedSeq[S], target: IndexedSeq[IndexedSeq[Array[Float]]]): Batch
    def fit(nn: NN, b: Batch): Unit
    def output[S: Statable](nn: NN, ls: IndexedSeq[S]): Array[IndexedSeq[Array[Float]]]

  }

  implicit class NeuralNOps[NN: NeuralN](n: NN) {

    val F = implicitly[NeuralN[NN]]

    def save(filename: String): Boolean =
      F.save(n, filename)

    def fit(b: F.Batch):Unit =
      F.fit(n, b)

    def fit(bi: Iterator[F.Batch]):Unit =
      bi.foreach(fit)

    def fit[S: Statable](si: Iterator[PreBatch[S]]):Unit =
      for (s <- si) {
        val b = F.buildBatch(s._1, s._2)
        fit(b)
       }

    def output[S: Statable](ls: IndexedSeq[S]): Array[IndexedSeq[Array[Float]]] =
      F.output(n, ls)

    def outputS[S: Statable](s: S): IndexedSeq[Array[Float]] =
      output(IndexedSeq(s)).map(_(0))

    def cloneM():NN =
      F.cloneM(n)


  }


  implicit object dl4j extends NeuralN[ComputationGraph] {

    type NN = ComputationGraph
    type Batch = MultiDataSet

    def build[S: Statable](conf: ConfNN):NN  = {
      val cgConf = BuildNN.buildCG[S](conf)
      val model = new ComputationGraph(cgConf)
      model.init()
      model.setListeners(new ScoreIterationListener(1))
      model
    }

    def load(filename: String) = {
      ModelSerializer.restoreComputationGraph(new File(filename))
    }

    def save(nn: NN, filename: String) =  {
      ModelSerializer.writeModel(nn, new File(filename), true)
      true
    }

    def genInput[S: Statable](seqs: IndexedSeq[S]) = {
  //    println(seqs.length + " " + seqs(0).toInput.length)
      val r = Nd4j.create(seqs.map(x => x.toInput.toArray).toArray)
//      println(r.rows() + " " + r.columns())
      r
    }//.reshape(seqs.length, implicitly[Statable[S]].featureSize)

    def buildBatch[S: Statable](seqs: IndexedSeq[S], target: IndexedSeq[IndexedSeq[Array[Float]]]): Batch = {
      val in = genInput(seqs)
      val out = target.map(ht => Nd4j.create(ht.toArray)).toArray
      new MultiDataSet(Array(in), out)
    }

    def cloneM(nn: NN) =
      nn.clone()

    def fit(nn: NN, b: Batch) =
        nn.fit(b)


    def output[S: Statable](nn: NN, ls: IndexedSeq[S]) = {
      val o = nn.output(genInput(ls))
//      println("O"+o.toList + ls.length)
      val r = o.map(h => (0 until ls.length).map(i => h.getRow(i).dup().data().asFloat()).toIndexedSeq)
//      println(r.toList.map(_.toList.map(_.toList)))
      o.map(h => (0 until ls.length).map(i => h.getRow(i).dup().data().asFloat()).toIndexedSeq)
    }


  }

}
