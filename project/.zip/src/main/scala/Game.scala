package ccup


sealed trait Opponent
case object PerfectCollab extends Opponent
case object RandomO extends Opponent


sealed trait Move extends MDP.Action
case object NoMove extends Move
case object Start extends Move
case class Turn(dir: Direction) extends Move
case class Place(x: Int, y: Int, c: Color) extends Move


case class Game(grid: Grid, turn: Int, maxScore: Float) {

  lazy val canContinue =
    turn < Conf.gameL && !availableMoveNext.isEmpty

  def placeColor =
    Game.placeColor(turn)


  lazy val toInput = {
//    Array(turn.toFloat)
//    grid.parameters ++ gridInputRaw :+ turn.toFloat :+ turn%5.toFloat :+ { if (canContinue) 1f else 0f }
    grid.toInput.toIndexedSeq :+ (1f-turn.toFloat/Conf.gameL) :+ (turn%5.toFloat)/5

//    gridInputRaw  :+ (turn%5.toFloat)/5
  }

  def canTurn(dir: Direction) = {
    move(Turn(dir)).exists(_.grid != grid)
  }


  def move(mv: Move) = {

    val ng = mv match {
        case Turn(dir) if placeColor.isEmpty =>
          Some(grid.move(dir)._1)
        case Place(x, y, c) if placeColor.exists(_ == c) =>
          grid.place(x, y, new Piece(1, c))
        case _ =>
          println("NOOOZ:" + mv)
          None //:<
      }

      ng.map(g => Game(g, turn+1, maxScore.max(grid.value)))

//      if (SoloGame.buildSeen && ogame.isDefined)
//        SelfPlay.seen ::= ogame.get.grid
//     */
  }


  def eval =
    grid.eval

  def value =
    grid.value

  def randomMove =  {
    val aM = availableMoveNext
    aM(util.Random.nextInt(aM.length))
  }

  def applyRandomMove =
    if (canContinue)
      move(randomMove).get
    else
      this

  def applyEvalMove =  {
    val aM = availableMoveNext
    aM.map(m => move(m).get).maxBy(_.grid.eval)
  }



  lazy val availableMoveNext = {
    val aM =
      if (turn == Conf.gameL)
        List()
      else
        (turn % 5) match {
          case 3 | 4  => Game.ALL_TURNS filter (x => canTurn(x.dir)) toList
          case t =>
            val color = Game.placeColor(t).get
            grid.emptySpots.map(p => Place(p._1, p._2, color)).toList
        }
    aM
  }
//    List(availableMoveGen(turn+1).map(x => (x, move(x).get)).maxBy(_._2.grid.eval)._1)

}

object Game {

  val ALL_TURNS = IndexedSeq(Turn(Up), Turn(Down), Turn(Right), Turn(Left))

  val colors = List(Blue, Red, Gray)

  val moves = (0 to 51).map( i =>
    if (i < 48)
      Place((i%16)%4, (i%16)/4, colors(i/16))
    else
      Game.ALL_TURNS(i-48)
  )



  def player(turn: Int) =
    (turn+1)%2

  def placeColor(turn: Int): Option[Color] =
    (turn % 5) match {
      case 3 | 4 => None
      case 0 => Some(Blue)
      case 1 => Some(Red)
      case 2 => Some(Gray)
    }


  def newGame =
    Game(Grid(), 0, 0)

}

case class Game2048(grid: GridIS, turn: Int) {

  lazy val toInput = {
    grid.toInputRed
  }

  def canTurn(dir: Direction) = {
    fullMove(Turn(dir))._1.grid != grid
  }

  def move(mv: Move) = {

    val ng = mv match {
        case Turn(dir) =>
          val (ng, r) = grid.move(dir)
          (ng, r)
      }

    (Game2048(ng._1, turn+1), ng._2)

  }

  def randomPlace() = {
    val es = grid.emptySpots
    if (!es.isEmpty) {
      val spot = Rand.choose(grid.emptySpots)
      copy(grid = grid.place(spot._1, spot._2, new Piece(1, Red)).get)
    } else
      this
  }

  def fullMove(m: Move) = {
    val (ng, r) = move(m)
    (ng.randomPlace(), r)
  }

  def eval =
    grid.eval

  def value =
    grid.value

  lazy val availableMoveNext = {
    if (!grid.emptySpots.isEmpty)
      Game.ALL_TURNS filter (x => canTurn(x.dir)) toList
    else
      List()
  }
//    List(availableMoveGen(turn+1).map(x => (x, move(x).get)).maxBy(_._2.grid.eval)._1)

}
