/*package ccup

import org.deeplearning4j.datasets.fetchers._
import org.deeplearning4j.datasets.iterator._
import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.api.ndarray.INDArray
import org.deeplearning4j.nn.graph.ComputationGraph
import org.nd4j.linalg.dataset._
import java.nio.file._
import java.nio._
import java.io._

import MDP._

class GameFetcherDataSL(nbEx: Int) extends BaseDataFetcher{

  totalExamples = nbEx
  reset()

  var files = scala.tools.nsc.io.Directory("games/").files.toList.take(1000)

  var gameList = util.Random.shuffle(files.flatMap(LocalReader.createSet))

  override def reset() = {
    cursor = 0
  }

  override def fetch(nb: Int) = {
    val games = gameList.drop(cursor).take(nb).toIndexedSeq

    val in = GameFetcher.genInput(games)
    val out = GameFetcher.genOutput(games)

    val inn = GameFetcher.normalizeInput(in)
    val outn = GameFetcher.normalizeOutput(out)

    val next: DataSet = new DataSet(inn, outn)

    cursor += nb
    curr = next
  }

}

object GameFetcher {

  val featureSize = Game.newGame.toInput.length//59

  var meanI, meanO, stdI, stdO:INDArray =_
  var mO, sO: Float=0f


  def genGamesTurn(nb: Int, turn:Int):IndexedSeq[Game] = (1 to nb).map(x => {
    val grid = Grid.random(turn)
    new Game(grid, turn, grid.value)
  })

  def genGames(nb: Int):IndexedSeq[Game] = (1 to nb).map(x => {
    val grid = Grid.random(Conf.gameL)
    new Game(grid, util.Random.nextInt(Conf.gameL+1), grid.value)
  })


  def genInput[S: Statable](states:IndexedSeq[S]) = {
    Nd4j.create(states.flatMap(x => (x.toInput)).toArray)
  }


  def genOutput[S: Statable](states:IndexedSeq[S]) =
    Nd4j.create(states.map(x => x.value.toFloat).toArray)

  def saveNormalization() = {
    val meanIDS = new DataOutputStream(Files.newOutputStream(Paths.get("meanI.bin")))
    val meanODS = new DataOutputStream(Files.newOutputStream(Paths.get("meanO.bin")))
    val stdIDS = new DataOutputStream(Files.newOutputStream(Paths.get("stdI.bin")))
    val stdODS = new DataOutputStream(Files.newOutputStream(Paths.get("stdO.bin")))
    Nd4j.write(meanI, meanIDS)
    Nd4j.write(meanO, meanODS)
    Nd4j.write(stdI, stdIDS)
    Nd4j.write(stdO, stdODS)
  }

  def loadNormalization()  = {
    val meanIDI = new DataInputStream(new FileInputStream("meanI.bin"))
    val meanODI = new DataInputStream(new FileInputStream("meanO.bin"))
    val stdIDI = new DataInputStream(new FileInputStream("stdI.bin"))
    val stdODI = new DataInputStream(new FileInputStream("stdO.bin"))
    meanI = Nd4j.read(meanIDI)
    meanO = Nd4j.read(meanODI)
    stdI = Nd4j.read(stdIDI)
    stdO = Nd4j.read(stdODI)
    loadNormFloat()
  }

  def loadNormFloat() = {
    mO = meanO.data().asFloat()(0)
    sO = stdO.data().asFloat()(0)
    println(mO + " " + sO)
  }

  def setupNormalization() = {

    val batchSize = 100000

    val games = genGames(batchSize)

    val gamesIn = genInput(games)
    val gamesOut = genOutput(games)
    //input
    val rs = gamesIn.reshape(batchSize, featureSize)
    meanI = rs.mean(0)

    stdI = rs.std(0)
    stdI.addi(Nd4j.scalar(Nd4j.EPS_THRESHOLD))

    //output
    val rs2 = gamesOut.reshape(batchSize, 1)

    //output
    meanO = rs2.mean(0)
    stdO = rs2.std(0)
    stdO.addi(Nd4j.scalar(Nd4j.EPS_THRESHOLD))

    loadNormFloat()
  }

  def normalizeInput(games: INDArray, batchSize:Int = 100) = {

    val rs =
      if (batchSize > 1)
        games.reshape(batchSize, featureSize)
      else
        games
    //    println("SHAPE:" + rs.rows() + "|" + rs.columns())
    rs//.subiRowVector(meanI).diviRowVector(stdI)
    //    r
  }

  def normalizeOutput(games: INDArray, batchSize:Int = 100) = {
    val rs =
      if (batchSize == 1)
        games
      else
        games.reshape(batchSize, 1)

    rs.subiRowVector(meanO).diviRowVector(stdO).reshape(batchSize, 1)
  }

  def rawOutput[S: Statable](model: ComputationGraph, s: S) = {
    val normInput = normalizeInput(Nd4j.create(s.toInput.toArray), 1)
    val outp = model.output(normInput)
    outp
  }

  def output[S: Statable](model: ComputationGraph, s: S, k:Int = 0) = {
    val outp = rawOutput(model, s)
    outp(k).data().asFloat()
  }


  def rawOutputs[S: Statable](model:ComputationGraph)(states:List[S]) = {
    val normInput = GameFetcher.normalizeInput(Nd4j.create(states.map(_.toInput.toArray).toArray), states.length)
    model.output(normInput)
  }

  def outputs[S: Statable](model:ComputationGraph, k:Int = 0)(games:List[S]) = {
    val outp = rawOutputs(model)(games)
    outp(k).data().asFloat()
  }


}

class GameFetcherRandomSL(nbEx: Int) extends BaseDataFetcher{

  totalExamples = nbEx

  override def reset() = {
    cursor = 0
  }

  var fetchNB = 0

  override def fetch(nb: Int) = {

    fetchNB += 1

    if (fetchNB % 10 == 0)
      println("SL Fetch nb: " +fetchNB)

    val games = GameFetcher.genGamesTurn(nb, 10)
    //    println(games)

    val in = GameFetcher.genInput(games)
    val out = GameFetcher.genOutput(games)

    val inn = GameFetcher.normalizeInput(in)
    val outn = GameFetcher.normalizeOutput(out)

    cursor += nb
    curr = new DataSet(inn, outn)

  }

}
 */
