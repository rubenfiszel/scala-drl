package ccup

case class Log(hist: List[(Game, Move)])

object Log {

  def read(s: List[Move]) = {
    val l = s.foldLeft((Game.newGame, List[Game]()))((acc, pos) => {
      val ng = acc._1.move(pos).get
      (ng, ng::acc._2)
    })
    l._2
  }

  def readM(m: String, turn: Int) =
    m match {
      case "U" => Turn(Up)
      case "D" => Turn(Down)
      case "R" => Turn(Right)
      case "L" => Turn(Left)
      case _ =>
        val y = m(0).toString.toInt-1
        val x = m(1).toString.toInt-1
        val c = Game.placeColor(turn).get
        Place(x, y, c)

    }

  def writeM(m: Move) = {
    m match {
      case Start => "S"
      case Turn(Up) => "U"
      case Turn(Down) => "D"
      case Turn(Left) => "L"
      case Turn(Right) => "R"
      case Place(x, y, c) => (y + 1).toString + (x + 1).toString
    }
  }

}
