/*package ccup

import org.deeplearning4j.datasets.fetchers._
import org.deeplearning4j.datasets.iterator._
import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.api.ndarray.INDArray
import org.deeplearning4j.nn.graph.ComputationGraph

object QL {

  var err = 0

  def scoreValue(g: Game) = {
    GameFetcher.normalizeOutput(Nd4j.create(Array(g.grid.value.toFloat)), 1).data().asFloat()(0)
  }



  def td(games: IndexedSeq[Game], maxTurn:Int = 1000)(evals: IndexedSeq[Game => Array[Float]]): (INDArray, INDArray) = {
    val agg = games.map(g =>
      error(g, maxTurn)(evals)).foldLeft((Array[Game](), Array[Float]()))((acc, pos) =>
      (acc._1 ++ pos._1, acc._2 ++ pos._2)
    )
    (GameFetcher.genInput(agg._1).reshape(agg._1.length, GameFetcher.featureSize), Nd4j.create(agg._2).reshape(agg._1.length, 1))
  }

  var tdnb = 0

  def error(g:Game, maxTurn:Int)(evals: IndexedSeq[Game => Array[Float]]): (Array[Game], Array[Float]) = {
    val qlearn =
      ql(g, evals)
    (Array[Game](), Array[Float]())
  }

  val allTurns = IndexedSeq(Up, Right, Down, Left)
  val colors = IndexedSeq(Blue, Red, Gray)
  def filterTurn(ar: Array[Float], grid:Grid):IndexedSeq[(Int, Float, Move)] =
    for {
      i <- (0 to 3) if (grid.move(allTurns(i)) != grid)
        } yield (i, ar(i), Turn(allTurns(i)))

  def filterPlace(ar:Array[Float], game:Game):IndexedSeq[(Int, Float, Move)] =
    for {
      i <- (0 to 15) if (game.grid.get(i%4, i%4).isEmpty)
        } yield (i, ar(i), Place(i%4, i/4, colors(game.turn+1)))

  val GAMMA = 0.8f

  def bestMove(ar:IndexedSeq[(Int, Float, Move)]) =
    ar.maxBy(_._2)

  def isPlace(g:Game) = g.turn%5<3

  def findBestMove(game: Game, evals: IndexedSeq[Game => Array[Float]]) = {
    val eval = evals(game.turn%5)(game)
    val moves =
      if (isPlace(game))
        filterPlace(eval, game)
      else
        filterTurn(eval, game.grid)

    bestMove(moves)
  }

  def ql(g: Game, evals: IndexedSeq[(Game => Array[Float])]) = {
    val nextMove = findBestMove(g, evals)
    val nextSN =
      g.move(nextMove._3).get

    val nextGame =
      nextSN

    val qmax = evals(nextGame.turn%5)(nextGame)
    val lg =
      if (isPlace(g))
        16
      else
        4
    (nextMove, Array.fill(4)(0).updated(nextMove._1, qmax))
  }


}
 */
