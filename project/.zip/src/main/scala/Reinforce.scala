package ccup


import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.api.ndarray.INDArray
import scala.util.Random
import org.deeplearning4j.nn.graph.ComputationGraph
import org.deeplearning4j.nn.api.Model
import org.deeplearning4j.datasets.fetchers._
import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.api.ndarray.INDArray
import org.deeplearning4j.nn.graph.ComputationGraph
import scala.collection.mutable.Queue
import org.nd4j.linalg.dataset._
import org.nd4j.linalg.dataset.api.iterator._
import org.nd4j.linalg.dataset.api.MultiDataSetPreProcessor
import scalax.chart.api._

import MDP._
import Backend._

object RL {
  var sc = List[Float]()
  var avg = List[Float]()
  var avg2 = List[Float]()
}

abstract class RL[S: Statable, B: NeuralN](model: B) extends Iterator[PreBatch[S]] {

  val series = new XYSeries("score-combined")
  val heads = new XYSeries("score-head")

  val chart = XYLineChart(series)
  val chart2 = XYLineChart(heads)

//  chart.show()
//  chart2.show()


  var nbFetch = 0
  var maxAvg = 0f


  def test(score:Float) {

      RL.sc ::= score


    if (RL.sc.length > Conf.nbAvg) {
      RL.avg ::= RL.sc.take(Conf.nbAvg).sum/Conf.nbAvg.toFloat
      RL.avg = RL.avg.take(Conf.nbAvg*3)
      RL.sc = RL.sc.dropRight(1)
      if (RL.avg.head > maxAvg+2) {
        maxAvg = RL.avg.head
        println("!!!NEW MAX FOUND: " + maxAvg + " nbFetch: " + nbFetch)
        model.save("maxconf-new-Deep-"+maxAvg.toInt.toString+"-"+nbFetch+".json")
      }
      swing.Swing onEDT {
        series.add(nbFetch.toDouble, RL.sc.head)
      }
      println("AVG: " + RL.avg.take(5).mkString(" " ))
    }

  }


  def sample[S: Statable](pols: IndexedSeq[PolicyQ]) = {

    val F = implicitly[Statable[S]]
    val k = Random.nextInt(Conf.nbHead)
    val episode = RLValue.episodeQ(F.zero)(pols(k))

    val lv = episode.map(_._3).sum
    println("L: "+ lv)


    swing.Swing onEDT {
      heads.add(nbFetch, lv)
    }
    if (nbFetch%20 == 0) {
      chart.saveAsPDF("head.pdf")
      chart2.saveAsPDF("head.pdf")
    }

    episode

  }

  def sample[S: Valuable](pols: IndexedSeq[PolicyV]) = {

    val F = implicitly[Valuable[S]]
    val k = Random.nextInt(Conf.nbHead)
    val episode = RLValue.episodeQV(F.zero)(pols(k))

    val lv = episode.map(_._3).sum
    println("Score: "+ lv)
    println("Turn: "+ episode.last._4.value)

    swing.Swing onEDT {
      heads.add(nbFetch, lv)
    }

    episode

  }


  def output[S: Statable](states: IndexedSeq[S], scores:IndexedSeq[Array[Array[Float]]]) = {
    (states, scores.map(_.toIndexedSeq))
  }


}



object RLValue {

  def getAtRandomPoint(l:List[Game], n:Int) = {
    var rand = util.Random.nextInt(l.length+1).min(l.length - n)
    l.drop(rand).take(n)
  }


  def episodeQ[S: Statable](s: S)(pol: PolicyQ): (List[SARS[S]]) = {
    var exps: List[SARS[S]] = List()
    var cs = s.F.zero
    while (cs.canContinue) {
      val action = pol.nextAction(cs)
      val (ns, reward) = cs.applyTransition(action)
      exps ::= ((cs, action, reward, ns))
      cs = ns
    }
    //    games ::= (cg, NoMove, 0f, cg) //to train to 0f the end
    exps.reverse
  }

  def episodeQV[S: Valuable](s: S)(pol: PolicyV): (List[SARS[S]]) = {
    var exps: List[SARS[S]] = List()
    var cs = s.F.zero
    while (cs.canContinue) {
      val action = pol.nextAction(cs)
      val (ns, reward) = cs.applyTransition(action)
      exps ::= ((cs, action, reward, ns))
      cs = ns
    }
    //    games ::= (cg, NoMove, 0f, cg) //to train to 0f the end
    exps.reverse
  }


}
